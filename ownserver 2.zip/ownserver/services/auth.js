module.exports = function(userid, pwd){
    return (userid == pwd);
}