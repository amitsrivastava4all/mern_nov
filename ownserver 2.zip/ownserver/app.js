const http = require('http');
//const fileServe = require('./fileserve');
const fileOperations = require('./fileserve');
const urlObj = require('url');
const server =http.createServer((request, response)=>{
    console.log(request.url);
    let url = request.url;
    let method = request.method;
    response.writeHead(200,{'Content-Type':'text/html'});
    if(url=='/'){
        url = '/index.html';
    }
    if(fileOperations.isStaticFile(url)){
        fileOperations.serveStatic(response, url);
    }
    else
    if(url.startsWith('/login') && method ==='GET'){
        //const obj = urlObj.parse(url, true); // Legacy
        console.log('Base ', request.headers.host);
        const baseURL = 'http://' + request.headers.host + '/';
        const obj = new urlObj.URL(url, baseURL);
        const itr = obj.searchParams.entries();
        const userid = itr.next().value[1];
        const pwd = itr.next().value[1];

        const auth = require('./services/auth');
        //if(auth(obj.userid, obj.password)){
            if(auth(userid, pwd)){
            response.write('Login SuccessFully ....');
        }
        else{
            response.write('Invalid Userid or Password');
        }
        response.end();


    }
    else
    if(url.startsWith('/login') && method ==='POST'){
       let data  = '';
       request.on('data',(chunk)=>{
        data+=chunk;
       })
       request.on('end',()=>{
           const queryString = require('querystring');
           const obj = queryString.parse(data);
           console.log("Post Data ",obj);

           const auth = require('./services/auth');
        if(auth(obj.userid, obj.password)){
            response.write('Login SuccessFully ....');
        }
        else{
            response.write('Invalid Userid or Password');
        }
        response.end();

       })



    }
    //fileServe(response);
    //console.log('Request Rec ');
    /*response.writeHead(200,{'Content-Type':'text/html'});
    response.write("Hi Node JS ",(err)=>{

    });
    response.write('<h1>Hello Client</h1>');
    response.end();*/
});
server.listen(process.env.PORT || 7777,(err)=>{
    if(err){
        console.log('Server Exit Due to Error ',err);
        process.exit();
    }
    else{
        console.log('Server Started... ', server.address().port);
    }
})