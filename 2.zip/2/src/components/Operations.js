import React from 'react';
export const Operations = (props)=>{
    console.log('Operation Call');
    return (
        <>
        <button onClick={props.click}>{props.title}</button>
        </>
    );
}