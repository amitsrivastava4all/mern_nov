export const CONFIG = {
    URL:'https://raw.githubusercontent.com/amitsrivastava4all/mern_jan/main/products.json'
}