import React from 'react';
import { SearchInput } from '../components/searchpage/SearchInput';
import { fetchProducts } from '../utils/ajax';
export class SearchPage extends React.PureComponent{
    constructor(props){
        super(props);
        this.state = {};
        console.log('1. Constructor Invoke');
    }
    static getDerivedStateFromProps(nextProps, prevState) { // Rarely Used

    }


    UNSAFE_componentWillMount(){
        console.log("2. Will Mount Call");
    }
    render(){
        console.log("3. Render");
        return (
            <SearchInput/>
        )
    }
    dataCallBack(responseData){
        console.log('Response Data in CallBack ',responseData);
        let object = JSON.parse(responseData);
        console.log(typeof responseData);
        console.log("Object is ",object);
    }
    componentDidMount(){
        fetchProducts(this.dataCallBack);
        console.log("4. Did Mount Call");
    }
    componentDidUpdate(){
        console.log('Change Happen');
    }
    componentWillUnmount(){
        // Clean Up code
    }
    /*shouldComponentUpdate(nextProps, nextStates){
        if(this.props.x != nextProps.x){
        return true;
        }
        this.state == nextStates
        return false;
    }*/
}