const fs = require('fs');
const path = require('path');


const fileServeOperations = {
    isStaticFile(currentFile){
        const staticContent = [".html",".css",
        ".jpg",".png", ".js"];
        const extension  = path.extname(currentFile);
        const index = staticContent.indexOf(extension);
        return index>=0;
    },
    serveStatic(response, fileName){

            const fullPath= path.join(__dirname,'/public', fileName);
            fs.readFile(fullPath,(err, buffer)=>{
                if(err){
                    response.write('404 File is Missing');

                }
                else{
                    response.write(buffer);
                }
                response.end();

            })
        }

}
module.exports = fileServeOperations;

