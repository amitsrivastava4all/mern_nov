import { Route, Switch } from "react-router"
import { Question } from "../components/engine/Question"
import { ReadQuestion } from "../components/engine/ReadQuestion"
import { Home } from "../components/Home"
import { config } from "./config"

export const DashBoardRoutes = ()=>{
    return (
        <Switch>
            <Route exact path={config.ROUTES.HOME} component={Home}/>
            <Route path={config.ROUTES.ADD_QUESTION} component={Question}/>
            <Route path={config.ROUTES.VIEW_QUESTIONS} component={ReadQuestion}/>
        </Switch>
    )
}