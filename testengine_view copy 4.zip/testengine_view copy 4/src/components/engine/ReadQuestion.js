import React from 'react';
export const ReadQuestion = ()=>{
    return (
        <div>
            Read Question Logic
        </div>
    );
}