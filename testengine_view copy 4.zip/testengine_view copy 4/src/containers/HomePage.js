import React, { useEffect, useState } from 'react';
import firebaseConfig from '../utils/firebase_config';
import './HomePage.css';
import firebase from "firebase/app";
import "firebase/auth";
import { ajaxOperations } from '../utils/ajax';
import { config } from '../utils/config';
import { DashBoard } from '../components/DashBoard';
import { homePageJSX } from '../utils/homepagejsx';
export const Home = ()=>{
    var role = '';
    const [isLoggedIn,setFlag] = useState(false);
    const [loginFail, setError] = useState({}) ;
    const [isLoaded, setLoaded] = useState(true);
    const [userInfoObject,setUserInfo] = useState({});

    useEffect(()=>{

       // console.log('*********************** ', typeof firebase.auth);
        firebase.auth().onAuthStateChanged((user)=>{
            if(user){
                //console.log('User Logged In ', user);
                //console.log(user.displayName, user.email, user.photoURL);
                user.currentRoleName = role;
                console.log('user :::::::::::',user);
                const promise = ajaxOperations.postNoIntercept(config.URLS.OAUTH, {'role':user.currentRoleName,'email':user.email, 'name':user.displayName, 'photo':user.photoURL});
                promise.then(response=>{
                     let userInfo = response.data?.userinfo;
                    console.log('Response is :::: ',userInfo);
                    if(userInfo){
                        localStorage.tokenId = response.data.tokenid;
                        console.log('::::::::During SetState UserInfo ',userInfo, response.data.tokenid);
                        setUserInfo(userInfo);
                        setLoaded(false);
                        setFlag(true);

                    }
                    else{
                        setError({message:'Login Failed No User Detail Found...'});
                    }
                }).catch(err=>{
                    console.log(err);
                    setError({message:'Login Failed, Contact to System Admin'});
                })
            }
            else{
                console.log('User Logout ', user);
            }
        })
    },[]);

    const OAuth = (roleName='student')=>{
        role = roleName;
        console.log('Role Set ',role);
        //console.log('FireBase Object is ', firebase);
        const googleAuthProvider = new firebase.auth.GoogleAuthProvider();
        firebase.auth().signInWithPopup(googleAuthProvider);
    }
    let jsx ;
    if(isLoaded){
        jsx = homePageJSX({OAuth});
    //    jsx =  <>
    //    <fieldset><legend>Student Login</legend>
    //    <button onClick={OAuth} className = 'btn btn-primary'>Login with Gmail</button>;
    //    </fieldset>
    //    <fieldset><legend>Teacher Login</legend>
    //    <button onClick={OAuth} className = 'btn btn-primary'>Login with Gmail</button>
    //    </fieldset>
    //    </>
    }
    else if(!isLoggedIn){
        jsx = <p className='alert-danger'>Login Fail {loginFail.message}</p>;
    }
    else{
        jsx = <></>;
    }
    console.log('render userInfo is ', userInfoObject);
    return (


            <>
            {jsx}

            {isLoggedIn?<DashBoard userInfo={userInfoObject}/>:<></>}
            </>
    )
}