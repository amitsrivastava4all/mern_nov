window.addEventListener('load',bindEvents);
function bindEvents(){
    //var buttons = document.getElementsByTagName('button');
    var buttons = document.querySelectorAll('button');
    buttons.forEach(button=>button.
        addEventListener('click',printXorZero));
    // for(let button of buttons){
    //     button.addEventListener('click',printXorZero);
    // }
    // for(let i =0; i<buttons.length; i++){
    //     buttons[i].addEventListener('click',printXorZero);
    // }
}
var flag = true;
function printXorZero(){

    if(this.innerText.length==0){
        console.log('Print X or Zero called...', this);
    this.innerText = flag?'X':'0';
    flag = !flag;
    isGameOver();
    console.log('End');
    }
}

function isGameOver(){
    var buttons = document.getElementsByTagName('button');
    if(isRowSame(buttons[0], buttons[1], buttons[2])){
            document.getElementById('result')
            .innerText = 'Game Over';
    }
    if(isRowSame(buttons[3], buttons[4], buttons[5])){
        document.getElementById('result')
        .innerText = 'Game Over';
}
}

function isRowSame(one, two ,three){
    if(isNotBlank(one) && isNotBlank(two)
    && isNotBlank(three)){
        if(isCompare(one, two, three)){
            return true;
        }
    }
}
function isCompare(one, two, three){
    if(one.innerText == two.innerText
        && one.innerText == three.innerText){
            return true;
        }
        return false;
}
function isNotBlank(button){
    if(button && button.innerText.length>0 ){
        return true;
    }
    return false;
}




