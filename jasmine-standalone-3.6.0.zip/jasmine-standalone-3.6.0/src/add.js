function add(...arg){
    var sum = 0;
    for(let a of arg){
        sum+=isNaN(parseInt(a))?0:parseInt(a);
    }
    return sum;
    //return parseInt(x) + parseInt(y);
}