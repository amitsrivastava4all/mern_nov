class CustomerOpr{
    add(){

    }
    remove(){

    }
    search(){

    }
    update(){

    }

}