// add 2 numbers
// add 1 number
// add 0 number
//add 2 array
// add 2 string
//add 2 functions
//add array, function , number, string

describe("Add Suite",function(){
    it("should add 2 numbers",function(){
       var result =  add(10,20);
       expect(result).toBe(30);
    });
    it("should add 1 numbers",function(){
        // Comment
        /*
        Multi line
        */
        var result =  add(10);
       expect(result).toBe(10);
    });
    it("should add 0 numbers",function(){
        var result =  add();
       expect(result).toBe(0);
    });
    it("should add 2 string",function(){
        var result =  add("10","20");
       expect(result).toBe(30);
    });
    it("should add 1 string 1 number",function(){
        var result =  add(10,"20");
       expect(result).toBe(30);
    });
    it("should add n numbers",function(){
        var result =  add(10,20,30,40,50);
       expect(result).toBe(150);
    });
    it("should add n numbers and strings",function(){
        var result =  add("10",20,"30","Amit",50);
       expect(result).toBe(110);
    });
    it("should add 2 arrays",function(){

    });
    it("should add 2 functions",function(){

    });
})
