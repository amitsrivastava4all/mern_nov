import React from 'react';
export const Title = ()=>{
    console.log('Title Call');
    return (<h1>Greet App</h1>);
}