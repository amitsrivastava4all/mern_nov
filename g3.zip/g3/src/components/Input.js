import React from 'react';
export const Input = ({title,change,val})=>{
    console.log('Input Call');
    let placeHolder = `Type ${title} Here`;
    return (
        <>
        <label>{title}</label>
        <input value={val} onChange={change} type='text' placeholder={placeHolder}/>
        </>
    )
}