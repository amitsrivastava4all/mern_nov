import React from 'react';
export const Output = (props)=>{
    console.log('Output Call');
    return (
        <h3>{props.result}</h3>
    )
}