import React from 'react';
export const Operations = (props)=>{
    console.log('Operation Call');
    return (
        <>
        <button className={props.cssClass} onClick={props.click}>{props.title}</button>
        </>
    );
}