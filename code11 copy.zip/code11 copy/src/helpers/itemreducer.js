import {shopState} from '../models/shopmodel';
import { CONFIG } from '../utils/constants';
export const ItemReducer = (state=shopState , action)=>{
    if(action.type==CONFIG.ACTION_TYPES.LOAD){
        console.log("Inside IF LOAD ",action);
        return {...state,items:action.payload.items};
    }
    return state;
}