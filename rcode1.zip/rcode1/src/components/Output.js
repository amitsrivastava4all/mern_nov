import React from 'react';
export const Output = (props)=>{
    return (
        <h3>{props.result}</h3>
    )
}