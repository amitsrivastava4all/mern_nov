import React from 'react';
export const Title = ()=>{
    return (<h1>Greet App</h1>);
}