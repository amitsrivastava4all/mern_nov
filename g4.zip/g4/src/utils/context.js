import React from 'react';
//React.createContext(object); // object represent common data
const CommonContext = React.createContext
({total:0,updateTotal:function(){}});
export default CommonContext;