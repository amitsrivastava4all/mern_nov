export const config = {

    URLS :{
        BASEURL:'http://localhost:1234',
        QUESTION_ADD_URL : '/questions/addquestion',
        QUESTION_FETCH_URL:'/questions/getquestions'
    }
}