import React from 'react';
import { DashBoard } from './components/DashBoard';
import {Question} from './components/engine/Question';
const App = ()=>{
  return (
    <div className = 'container'>
        <DashBoard/>
      </div>
  );
}
export default App;