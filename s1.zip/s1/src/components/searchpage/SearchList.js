import React from 'react'
import { NoRecordFound } from './NotRecordFound'
import {Item} from './Item';
export const  SearchList=(props)=> {


    return (
        <>

            {props.products.map((product,index)=><Item key={product.id}  product= {product}/>)}
        </>
    )
}
