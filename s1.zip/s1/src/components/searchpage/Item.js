import React from 'react'
import { Addtocart } from './AddToCart'

export const  Item=(props)=> {
    const myStyle = {
        width:'100px',
        height:'100px'
    }

    return (

        <div>
            {props.product.name} {props.product.price}
            <img style={myStyle} src={props.product.url}/>
            <Addtocart/>
            </div>

    )
}
