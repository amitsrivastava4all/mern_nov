import React from 'react';
import { NoRecordFound } from '../components/searchpage/NotRecordFound';
import { SearchInput } from '../components/searchpage/SearchInput';
import { SearchList } from '../components/searchpage/SearchList';
import { TotalItemsInCart } from '../components/searchpage/TotalItems';
import { fetchProducts } from '../utils/ajax';
export class SearchPage
//extends React.Component{
extends React.PureComponent{
    constructor(props){
        super(props);
        this.state = {products:[]};
        console.log('1. Constructor Invoke');
    }
    static getDerivedStateFromProps(nextProps, prevState) { // Rarely Used

    }


    UNSAFE_componentWillMount(){
        console.log("2. Will Mount Call");
    }
    render(){
        console.log("3. Render");
        return (
            <>
            <TotalItemsInCart/>
            <SearchInput/>
            {this.state.products.length===0?<NoRecordFound/>
            :<SearchList products={this.state.products}/>}

            </>
        )
    }
    dataCallBack(responseData){
        console.log('Response Data in CallBack ',responseData);
        let object = JSON.parse(responseData);
        console.log(typeof responseData);
        console.log("Object is ",object.mobiles);
        this.setState({products:object.mobiles});
    }
    componentDidMount(){
        //let bindedWithThis = this.dataCallBack.bind(this);
        //fetchProducts(bindedWithThis);
        fetchProducts(this.dataCallBack.bind(this));
        console.log("4. Did Mount Call");
    }
    componentDidUpdate(){
        console.log('Change Happen');
    }
    componentWillUnmount(){
        // Clean Up code
    }
    /*shouldComponentUpdate(nextProps, nextStates){
        //return true;

         if(this.props.x != nextProps.x){
         return true;
         }
         return false;
        // this.state == nextStates
        // return false;
    }*/
}