import { Greet } from "./containers/Greet"
import React from 'react';
const App = ()=>{
  return (
    <Greet/>
  )
}
export default App;