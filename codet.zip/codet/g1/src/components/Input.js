import React from 'react';
export const Input = ({title,change})=>{
    console.log('Input Call');
    let placeHolder = `Type ${title} Here`;
    return (
        <>
        <label>{title}</label>
        <input onChange={change} type='text' placeholder={placeHolder}/>
        </>
    )
}