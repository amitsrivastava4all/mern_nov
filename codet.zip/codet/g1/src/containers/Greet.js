import { Title } from "../components/Title";
import React,{Component} from 'react';
import { Input } from "../components/Input";
import { Operations } from "../components/Operations";
import { Output } from "../components/Output";
export class Greet extends Component{
    constructor(){
        super();
        console.log('1. Init The Member Variables');
        this.firstName = '';
        this.lastName = '';
        this.fullName = '';
        //this.obj = {x:100,y:200};
        this.state = {msg:this.fullName,x : 100, y:200};

    }

    makeFullName(){
        //this.setState()
         this.fullName = this.initCap(this.firstName) + ' '+this.initCap(this.lastName);
        console.log('Full Name is ',this.fullName);
        this.setState({...this.state, msg:this.fullName});
        // this.state.msg = this.fullName;
        // this.setState(this.state);

    }
    initCap(str){
        return str.charAt(0).toUpperCase() + str.substring(1)
        .toLowerCase();
    }

    takeFirstName(event){

        console.log('I am Called...',event.target.value);
        this.firstName = event.target.value;
        console.log("First Name ",this.firstName);

    }
    takeLastName(event){

        console.log('I am Called Last Name...',event.target.value);
        this.lastName = event.target.value;
        console.log('Last Name ',this.lastName);
    }

    render(){
        console.log('2. Render Call');
        return (
            <div>


                         <Title/>
                         <Input change = {this.takeFirstName.bind(this)} title ="First Name"/>
                         <br/>
                         <Input change={this.takeLastName.bind(this)} title = "Last Name"/>
                         <br/>
                         <Operations click={this.makeFullName.bind(this)} title = 'Greet'/>
                         <Operations title = 'Clear All'/>
                         <Output result = {this.state.msg}/>
                     </div>
        )
    }

}
// export const Greet = ()=>{
//     return (
//         <div>
//             <Title/>
//             <Input title ="First Name"/>
//             <br/>
//             <Input title = "Last Name"/>
//             <br/>
//             <Operations title = 'Greet'/>
//             <Operations title = 'Clear All'/>
//             <Output result = ''/>
//         </div>
//     )
// }