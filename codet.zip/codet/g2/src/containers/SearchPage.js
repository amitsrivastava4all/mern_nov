import React, { Component } from 'react';

export default class Searchpage extends Component {
    constructor(props) {
        super(props);

        this.state = {

        }


    }






    render() {
        return (
            <>
                <h1>Search Page</h1>
            </>
        )
    }
}
