import React from 'react';
import Searchpage from './containers/SearchPage';
export default function App(props) {


  return (
    <>
    <Searchpage/>
    </>
  );
}
