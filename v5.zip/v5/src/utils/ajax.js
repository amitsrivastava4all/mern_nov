import { CONFIG } from "./constants";
import axios from 'axios';
// fn = dataCallBack

export function fetchProducts(){
    //axios.get(CONFIG.URL,{params:{name:'Amit'}})
   const promise =  axios.get(CONFIG.URL);
   return promise;
}


//export function fetchProducts(fn){


    /*
    var xmlHttpRequest = new window.XMLHttpRequest();
    xmlHttpRequest.onreadystatechange=function(){
        // console.log(xmlHttpRequest.readyState,
        // xmlHttpRequest.responseText);
        if(xmlHttpRequest.readyState==4 &&
        xmlHttpRequest.status==200){
            fn(xmlHttpRequest.responseText);
        //console.log('Data is ',xmlHttpRequest.responseText);
        }

        }
        xmlHttpRequest.open('GET',CONFIG.URL,true);
        xmlHttpRequest.send(null);
        */
   // }