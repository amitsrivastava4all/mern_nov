import axios from 'axios';
export function loadConfig(){
    axios.defaults.baseURL='https://raw.githubusercontent.com/brainmentorspvtltd/myserverdata/master';
    axios.interceptors.request.use((currentRequest)=>{
        console.log('Interceptor Called...');
        currentRequest.token = 'A12222222';
        return currentRequest;
        //currentRequest.token = localStorage.tokenId;
    },(err)=>{
        console.log('Interceptor Error ',err);
    });
    axios.interceptors.response.use((currentResponse)=>{
        console.log('Response Comes ',currentResponse);
        let tokenId = currentResponse.headers['AUTH-TOKEN'];
        localStorage.token = tokenId;
        return currentResponse;
    },(err)=>{

    })
}
