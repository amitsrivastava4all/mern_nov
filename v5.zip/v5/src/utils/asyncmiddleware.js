export const itemAsyncActionCreator = (data, name)=>{
    return dispatch=>{
        // Async Data Dispatch
        setTimeout(()=>{
            console.log('Timeout Start....');
            dispatch(
                {
                        payload:{
                           items:data
                        },
                        type:name
                    }
            );
            console.log('Data Prepare..........');
        },0);

    }
    // return {
    //     payload:{
    //        items:data
    //     },
    //     type:name
    // }
}