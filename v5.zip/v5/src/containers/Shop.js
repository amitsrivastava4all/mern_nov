import React from 'react';
import { Route, Switch } from 'react-router';
import { AddItems } from '../components/searchpage/AddItems';
import { Header } from '../widgets/Header';
import { About } from './About';
import { Home } from './Home';
import { SearchPage } from './SearchPage';
export const Shop = ()=>{
    return (
        <>
        <Header name='Amit' city='Delhi'/>
        <Switch>
            <Route exact path="/" component={Home}/>
            <Route path="/search" component={SearchPage}/>
            <Route path="/about/:customername/:city" component={About}/>
            <Route path ="/addproduct" component = {AddItems}/>
            {/* <Route component={FileNotFound}/> */}
            <Route render= {()=>{
                  return (<h1>OOPS U Type Something Else....</h1>)
            }}/>
        </Switch>
        </>
    )
}