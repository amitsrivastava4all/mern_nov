const error404 = (request, response)=>{
    //response.status(404).send('OOPS U Type Some Wrong URL');
    const path = require('path');
    const parent = path.normalize(__dirname+'/..');
    const fullPath = path.join(parent,'/public/error.html');
    response.status(404).sendFile(fullPath);
}
module.exports = error404;