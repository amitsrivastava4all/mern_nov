const questionOperations = require('../services/questionoperations');
const Question = require('../dto/question');
const questionController = {
    addQuestion(request, response){
        console.log('BOdy is ',request.body);
        const questionObject = new Question(request.body.name, request.body.answers, request.body.author);
        const promise = questionOperations.add(questionObject);
        promise.then(data=>{
        response.send('Question Added SuccessFully....');
        }).catch(err=>{
            response.send('Error During Addition of Question in DB');
            console.log(err);
        })


    },
    getQuestion(request, response){
        response.send('Get Question Route');
    }
}
module.exports = questionController;