const express = require('express');
const app = express();
const dotenv = require('dotenv');
dotenv.config();
app.use(express.static('public'));
app.use(express.json());
app.use(express.urlencoded());
app.use('/', require('./routes/userroute'));
app.use('/questions', require('./routes/questionroute'));
app.use(require('./utils/error404'));
// Route
/*app.get('/profile',(request, response)=>{
    response.send('Profile');
})*/
app.listen(1234,()=>{
    console.log('Server Started...');
})