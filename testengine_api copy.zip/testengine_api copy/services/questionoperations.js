/**
 * Maintain Question CRUD Operations
 * @author Amit Srivastava
 * @copyright Brain Mentors
 * @version 1.0
 * @summary Question CRUD File
 */

const QuestionModel = require('../db/models/questionschema');
const questionOperations = {
    add(questionObject){
            const promise = QuestionModel.create(questionObject);
            return promise;
    },
    delete(){

    },
    update(){

    },
    search(){

    }
}
module.exports =questionOperations;