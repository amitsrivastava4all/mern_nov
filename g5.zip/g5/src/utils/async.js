export function lazy(){
    const promise = new Promise((resolve, reject)=>{
        setTimeout(()=>{
            resolve(1000);
        },7000);
    })
    return promise;
}