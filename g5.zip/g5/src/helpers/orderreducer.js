import {shopState} from '../models/shopmodel';
import { CONFIG } from '../utils/constants';
export const OrderReducer = (state = shopState ,action)=>{
    if(action.type==CONFIG.ACTION_TYPES.ADD){

    }
    return state;
}