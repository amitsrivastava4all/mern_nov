import React from 'react'

export const About=(props)=> {

    console.log(props);
    return (
        <>
            <h1>I am About {props.match.params.customername}
            {props.match.params.city} </h1>

        </>
    )
}
