import React from 'react'

export const Creditcard = (props)=> {


    return (
        <>
            <h1>Credit Card</h1>
        </>
    )
}
