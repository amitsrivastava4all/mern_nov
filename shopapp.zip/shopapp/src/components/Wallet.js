import React from 'react'

export const Wallet = (props)=> {


    return (
        <>
            <h1>Wallet</h1>
        </>
    )
}
