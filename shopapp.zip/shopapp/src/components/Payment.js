import React from 'react'
import {NavLink} from 'react-router-dom';
export const Payment=(props)=> {


    return (
        <>
            <h1>Payment Page</h1>
            <NavLink activeClassName="active" className="nav-link" to="/payments/creditcard">Credit Card</NavLink>
            <NavLink activeClassName="active" className="nav-link" to="/payments/wallet">Wallet</NavLink>

        </>
    )
}
