import React from 'react'

export const  NoRecordFound=(props)=> {


    return (
        <>
            <h3>No Record Found ,Need to Search Something Else....</h3>
        </>
    )
}
