import React from 'react'
import CommonContext from '../../utils/context';
export const  TotalItemsInCart=(props)=> {

    console.log('I am in TotalItemsInCart');
    return (
        <>
            <CommonContext.Consumer>
                {
                        (shareObject)=>{
                            console.log('Share Object is ',shareObject);
                            return (<p>Total Items in Cart {shareObject.total}</p>);
                        }
                }


           </CommonContext.Consumer>
        </>
    )
}
