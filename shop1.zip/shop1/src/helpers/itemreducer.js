export const ItemReducer = (state= {}, action)=>{
    if(action.type=='LOAD'){
        console.log("Inside IF LOAD ",action);
        return {...state,items:action.payload.items};
    }
    return state;
}