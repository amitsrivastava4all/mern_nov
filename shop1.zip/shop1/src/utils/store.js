import {createStore} from 'redux';
import { ItemReducer } from '../helpers/itemreducer';
export const store = createStore(ItemReducer);
store.subscribe(()=>{
    console.log('State Updated... ',store.getState());
})