/**
 * Maintain DB Connection with Mongo Atlas with POOLSize of 5
 * @author Amit Srivastava
 * @copyright Brain Mentors
 * @version 1.0
 * @summary Connection File
 */

const mongoose = require('mongoose');
const dbOptions = {
    useNewUrlParser : true,
    poolSize:process.env.POOL_SIZE
};
mongoose.connect(process.env.DB_URL,dbOptions,(err)=>{
    if(err){
        console.log('DB Error ',err);
    }
    else{
        console.log('Connected to DB');
    }
});
// let db = mongoose.connection;
// db.on('open',()=>{

// });
// db.on('error',()=>{

// })
module.exports = mongoose;