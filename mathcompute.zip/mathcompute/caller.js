const calc= require('./index');
console.log(calc.add(100,200));
console.log(calc.sub(10,20));