# This is My Read Me File for Math Compute Docs for Ends Users
## Created by Amit
** Math Compute **
*It Contains the add function and subtract function *