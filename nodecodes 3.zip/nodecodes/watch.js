const fs = require('fs');
const p = '/Users/amit/Documents/react-feb-wend/nodecodes/xyz.txt';
console.log('Before watch');
fs.watchFile(p,(curr, prev)=>{
    if(curr!=prev){
    //console.log('File Change');
    console.log(fs.readFileSync(p).toString());
    }
})