const config = require('./config');
const dotconfig = require('dotenv');
dotconfig.config();
process.on('exit',()=>{
    console.log('App Exit');
})
process.on('uncaughtException',(err)=>{
    console.log('Something went Wrong on App ', err);
    console.log(err.code);
    console.log(err.message);
    console.log(err.stack);

    process.exit();

})
console.log('ARGS ' , process.argv);
const key  = process.argv[2];
if(key === 'DEV'){
 // Load Dev Config
 console.log(config[key]);
}
else if(key==='PROD'){
    console.log(config[key]);
}

console.log(process.env.PORT);
console.log(process.env.DBURL);

process.stdout.write('Hello STDOUT');
//process.exit();
console.log(process.cwd());
console.log(process.versions.node);
console.log(process.arch);
console.log(process.cpuUsage());
var x = 100;
var y = 200;
var z = x + y;
console.log("Z is ",z);
var i = 1;
var f = setInterval(() => {
    console.log('I is ',i);
    if(i>=10){
        throw new Error('App Generated Error');
    }
    i++;
}, 1000);
//clearInterval(f);

