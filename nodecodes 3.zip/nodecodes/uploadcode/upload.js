//const file = '/Users/amit/Documents/rocket.png'; // small
const file = '/Users/amit/Documents/softwares/Xcode_11.5.xip';
const fs = require('fs');
const path = require('path');
fs.readFile(file,(err, content)=>{
    if(err){
        console.log(err);
        throw err;
    }
    const parent = path.normalize(__dirname+'/..')
    const fullPath = path.join(parent,'/images/Xcode_11.5.xip');
    fs.writeFile(fullPath,content,(err)=>{
        if(err){
            console.log('Upload Error');
        }
        else{
            console.log('Uploaded done...');
        }
    })
})
