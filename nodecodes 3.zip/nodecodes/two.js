//const fn = require('./one');
//console.log(fn(100,200));
const obj = require('./one');
console.log(obj.add(10,20));
console.log(obj.sub(10,20));