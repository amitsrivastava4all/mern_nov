const config = {
    DEV:{
        DBURL:'mongo://localhost:27017/mydb',
        APIURL:''
    },
    PROD:{
        DBURL:'mongo://AtlasIP:27017/mydb',
    }
}
module.exports = config;