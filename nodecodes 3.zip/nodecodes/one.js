module.exports = {
    add(x=0,y=0){
        return x + y;
    },
    sub(x=0,y=0){
        return x - y;
    }
}
// module.exports = function add(x=0, y=0){
//     return x  + y;
// }
/*
function add(x=0, y=0){
    return x + y;
}
function subtract(x=0, y=0){
    return x - y;
}
module.exports.addition = add;
module.exports.subtraction = subtract;
*/
//console.log(add(100,200));
// var a = 100;
// var b = 200;
// var c = a + b;
// console.log('sum is ',c);