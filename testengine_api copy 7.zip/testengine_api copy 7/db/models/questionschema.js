/**
 * Maintain Question Schema
 * @author Amit Srivastava
 * @copyright Brain Mentors
 * @version 1.0
 * @summary Question Schema File
 */

const connection = require('../connect');
const {Schema} = require('mongoose');
const QuestionSchema = new Schema({
    name:{type:Schema.Types.String, required:true, unique:true, min:10, max:200},
    answers:{type:Schema.Types.Array},
    questionbank:{type:Schema.Types.String, default:'Y'},
    test_id:{type:Schema.Types.ObjectId, ref:'tests'} // join with test collection
    //,
    //author:{type:Schema.Types.ObjectId, ref:'users'} // Join

},{timestamps:true});
const QuestionModel = connection.model('questions',QuestionSchema);
module.exports = QuestionModel;