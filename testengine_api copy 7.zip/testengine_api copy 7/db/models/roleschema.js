/**
 * Maintain User Schema
 * @author Amit Srivastava
 * @copyright Brain Mentors
 * @version 1.0
 * @summary Role Schema File
 */

 const connection = require('../connect');
 const {Schema} = require('mongoose');
const { ROLE, RIGHT } = require('../../utils/constants').SCHEMAS;
const RightModel = require('../models/rightschema');
 const RoleSchema = new Schema({
     name:{type:Schema.Types.String, required:true,
        unique:true, min:3, max:25},
     description:{type:Schema.Types.String, required:true},
     status:{type:Schema.Types.String, default:'Y'},
     rightid:[{type:Schema.Types.ObjectId, ref:RIGHT}]  // (one to many) represent front end menu links

 },{timestamps:true});
 const RoleModel = connection.model(ROLE,RoleSchema);
 module.exports = RoleModel;




