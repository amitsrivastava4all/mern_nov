const express = require('express');
const route = express.Router();
const path = require('path');
const fs = require('fs');
route.get('/images/:name',(request, response)=>{
    let imagePath = process.env.RESOURCE_PATH;
    const fullPath = path.join(imagePath,'/'+request.params.name);
    const stream = fs.createReadStream(fullPath);
    stream.pipe(response);

})
module.exports = route;