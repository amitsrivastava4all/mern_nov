const questionOperations = require('../services/questionoperations');
const Question = require('../dto/question');
const logger = require('../utils/logger')(__filename);
const {SUCCESS, SERVER_ERROR} = require('../utils/constants').HTTP_CODES;
const messageBundle = require('../locales/en.json');
const questionController = {
    addQuestion(request, response){
        //console.log('BOdy is ',request.body);
        logger.debug('Body is '+JSON.stringify(request.body));
        const questionObject = new Question(request.body.name, request.body.answers, request.body.author, request.body.testId);
        const promise = questionOperations.add(questionObject);
        promise.then(data=>{
        //response.send('Question Added SuccessFully....');
        response.send(messageBundle['question.added']);
        }).catch(err=>{
            //response.send('Error During Addition of Question in DB');
            response.send(messageBundle['question.added.error']);
            logger.error(messageBundle['question.added.error']+JSON.stringify(err));
        })


    },
    getQuestionById(request, response){
        let id = request.query.id;
        console.log(request.query.id);
        //response.send('Request Comes ');

        const promise = questionOperations.findByQuestionId(id);
        promise.then(result=>{
            response.status(SUCCESS).json({"question":result});
        }).catch(err=>{
            response.status(SERVER_ERROR).json({'message':'Error in GET Questions '+JSON.stringify(err)});
        })
    },
    getQuestionByName(request, response){
        let name = request.params.name;
        console.log('Param Name is ',name);
        //response.send('Param Rec '+name);
        const promise = questionOperations.findByQuestionName(name);
        promise.then(result=>{
            response.status(SUCCESS).json({"question":result});
        }).catch(err=>{
            response.status(SERVER_ERROR).json({'message':'Error in GET Questions '+JSON.stringify(err)});
        })
    },
    getQuestions(request, response){
        const promise = questionOperations.readAll();
        promise.then(result=>{
            response.status(SUCCESS).json({"questions":result});
        }).catch(err=>{
            response.status(SERVER_ERROR).json({'message':'Error in GET Questions '+JSON.stringify(err)});
        })
    }
}
module.exports = questionController;