class Question{
    constructor(name, answers, author, testId=0){
        this.name = name;
        this.answers = answers;
        this.author = author;
        this.testId = testId;
    }
}
module.exports = Question;