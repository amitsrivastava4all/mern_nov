module.exports = class User{
    constructor(email, name, photo, roleid="60a69a964471cf5e22afab96"){
            this.email = email;
            this.name = name;
            this.photo = photo;
            this.roleid = roleid;

    }
}