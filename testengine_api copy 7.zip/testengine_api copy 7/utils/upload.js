
const path = require('path');
const fs = require('fs');
const config = require('./constants');
function uploadFile(request, response){
if(!request.files || Object.keys(request.files).length==0){
    response.status(500).json({message:'No file to Upload '});
}
else{
    let file = request.files.uploadpic; //<input type=‘file’ name=‘uploadpic’>
    console.log('FILE IS ',file);
    let fullPath = path.join(config.UPLOAD_FILE_LOCATION, file.name);
    try{
    fs.writeFileSync(fullPath,file.data);
        response.status(200).json({message:'File Uploaded...'});
}
    catch(err){
        response.status(200).json({message:'Error in  Upload...'});
        console.log('Error in File Upload ',err);
    }
}
}
module.exports = uploadFile;