const constants = {
    HTTP_CODES :{
        SUCCESS:200,
        SERVER_ERROR:500,
        FILE_NOT_FOUND:404,
        UNAUTHORIZED:401
    },
    SCHEMAS:{
        ROLE:'roles',
        RIGHT:'rights'
    },
    SALT:10,
    UPLOAD_FILE_LOCATION:'/Users/amit/Documents/test_engine_project/testengine_api/uploads'
}
module.exports = constants;