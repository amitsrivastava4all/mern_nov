const fs = require('fs');
console.log('Start');
try{
const content = fs.readFileSync(__filename);
console.log(content.toString());
console.log('End');
}
catch(e){
    console.log(e);
}