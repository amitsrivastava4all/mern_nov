const fs = require('fs');
const path = require('path');
const filePath = path.join(__dirname,'/one.js')
//const filePath = '/Users/amit/Documents/react-feb-wend/nodecodes/one.js';
console.log('Before');
fs.readFile(filePath,(err, content)=>{
    if(err){
        console.log('Error in File Read ',err);
    }
    else{
        console.log(content.toString());
    }
});
fs.readFile(path.join(__dirname,'/two.js'),(err, content)=>{
    if(err){
        console.log('Error in File Read ',err);
    }
    else{
        console.log(content.toString());
    }
});
console.log('After');