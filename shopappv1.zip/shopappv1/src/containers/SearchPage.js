import React from 'react';
import { SearchInput } from '../components/searchpage/SearchInput';
export class SearchPage extends React.Component{
    constructor(props){
        super(props);
    }
    render(){
        return (
            <SearchInput/>
        )
    }
}