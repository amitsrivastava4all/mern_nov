export const config = {
    url:'https://raw.githubusercontent.com/amitsrivastava4all/mern_jan/main/products.json'
}