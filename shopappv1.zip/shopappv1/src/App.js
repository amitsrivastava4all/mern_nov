import React from 'react';
import {SearchPage} from './containers/SearchPage';
const App = (props)=>{
  return (
    <div className='container'>
      <SearchPage/>
    </div>
  );
}
export default App;