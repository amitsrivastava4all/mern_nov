const file = '/Users/amit/Documents/softwares/Xcode_11.5.xip';
const fs = require('fs');
//const https = require('https');
//const rstream = fs.createReadStream(file,{highWaterMark:100000});
const rstream = fs.createReadStream(file);
const wstream = fs.createWriteStream('/Users/amit/Documents/softwares/Xcode_11.5Clone.xip')
rstream.on('open',()=>{
    console.log('Stream Open');
});
rstream.pipe(wstream);
// rstream.on('data',(chunk)=>{
//    // console.log('Chunk ',chunk);
//     wstream.write(chunk);
// })
rstream.on('end',()=>{
    console.log('Stream End');
});
rstream.on('error',(err)=>{
    console.log('Stream Error ',err);
})
rstream.on('close',()=>{
    console.log('Close');
})