const fs = require('fs');
fs.writeFile('xyz.txt',"Hello this is the content",(err)=>{
    console.log(err?'Error in File Write ':'Write Done...');
    if(!err){
    fs.appendFile('xyz.txt','hgdjkfhkghfdghdfg',(err)=>{
        console.log(err?'Error in File Write ':'Append Done...');
    })
}
})
fs.copyFile('source','dest',(err)=>{

})
fs.mkdir('abcd',err=>{

})
fs.readdir('path',(err,folders)=>{

})
fs.rename('oldfilepath','newfilepath',(err)=>{

})

fs.unlink('xyz.txt',(err)=>{

})