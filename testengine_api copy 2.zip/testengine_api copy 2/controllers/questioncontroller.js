const questionOperations = require('../services/questionoperations');
const Question = require('../dto/question');
const questionController = {
    addQuestion(request, response){
        console.log('BOdy is ',request.body);
        const questionObject = new Question(request.body.name, request.body.answers, request.body.author);
        const promise = questionOperations.add(questionObject);
        promise.then(data=>{
        response.send('Question Added SuccessFully....');
        }).catch(err=>{
            response.send('Error During Addition of Question in DB');
            console.log(err);
        })


    },
    getQuestionById(request, response){
        let id = request.query.id;
        console.log(request.query.id);
        //response.send('Request Comes ');

        const promise = questionOperations.findByQuestionId(id);
        promise.then(result=>{
            response.status(200).json({"question":result});
        }).catch(err=>{
            response.status(500).json({'message':'Error in GET Questions '+JSON.stringify(err)});
        })
    },
    getQuestionByName(request, response){
        let name = request.params.name;
        console.log('Param Name is ',name);
        //response.send('Param Rec '+name);
        const promise = questionOperations.findByQuestionName(name);
        promise.then(result=>{
            response.status(200).json({"question":result});
        }).catch(err=>{
            response.status(500).json({'message':'Error in GET Questions '+JSON.stringify(err)});
        })
    },
    getQuestions(request, response){
        const promise = questionOperations.readAll();
        promise.then(result=>{
            response.status(200).json({"questions":result});
        }).catch(err=>{
            response.status(500).json({'message':'Error in GET Questions '+JSON.stringify(err)});
        })
    }
}
module.exports = questionController;