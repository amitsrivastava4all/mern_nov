const http = require('http');
const fileServe = require('./fileserve');
const server =http.createServer((request, response)=>{
    console.log(request.url);
    response.writeHead(200,{'Content-Type':'text/html'});
    fileServe(response);
    //console.log('Request Rec ');
    /*response.writeHead(200,{'Content-Type':'text/html'});
    response.write("Hi Node JS ",(err)=>{

    });
    response.write('<h1>Hello Client</h1>');
    response.end();*/
});
server.listen(process.env.PORT || 7777,(err)=>{
    if(err){
        console.log('Server Exit Due to Error ',err);
        process.exit();
    }
    else{
        console.log('Server Started... ', server.address().port);
    }
})