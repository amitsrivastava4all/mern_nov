const fs = require('fs');
const path = require('path');
module.exports =   (response)=>{
    const fullPath= path.join(__dirname,'/public/index.html');
    fs.readFile(fullPath,(err, buffer)=>{
        if(err){
            response.write('404 File is Missing');

        }
        else{
            response.write(buffer);
        }
        response.end();

    })
}