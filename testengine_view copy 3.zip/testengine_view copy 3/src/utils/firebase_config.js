import  firebase from 'firebase/app';
import 'firebase/analytics';



  // Your web app's Firebase configuration
  // For Firebase JS SDK v7.20.0 and later, measurementId is optional
  var firebaseConfig = {
    apiKey: "AIzaSyDvsAbTd5nt__Lrba226JvmL-8QKhlObuY",
    authDomain: "oauthdemoapp-3f7d4.firebaseapp.com",
    projectId: "oauthdemoapp-3f7d4",
    storageBucket: "oauthdemoapp-3f7d4.appspot.com",
    messagingSenderId: "71386538032",
    appId: "1:71386538032:web:323384f7fc19b96a8e0df5",
    measurementId: "G-G8R6EVMP13"
  };
  console.log('Config Loaded ', firebase);
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  firebase.analytics();
  export default firebase;
