import React from 'react';
import { DashBoard } from './components/DashBoard';
import {Question} from './components/engine/Question';
import { Home } from './containers/HomePage';
import {loadInterceptor} from './utils/interceptor';
loadInterceptor();

const App = ()=>{
  return (
    <div className = 'container'>
        <Home/>
      </div>
  );
}
export default App;