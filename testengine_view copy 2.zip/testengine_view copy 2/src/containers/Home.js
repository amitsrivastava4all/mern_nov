import React, { useEffect } from 'react';
import firebaseConfig from '../utils/firebase_config';

import firebase from "firebase/app";
import "firebase/auth";
export const Home = ()=>{

    useEffect(()=>{
        console.log('*********************** ', typeof firebase.auth);
        firebase.auth().onAuthStateChanged((user)=>{
            if(user){
                console.log('User Logged In ', user);
                console.log(user.displayName, user.email, user.photoURL);
            }
            else{
                console.log('User Logout ', user);
            }
        })
    },[]);

    const OAuth = ()=>{
        console.log('FireBase Object is ', firebase);
        const googleAuthProvider = new firebase.auth.GoogleAuthProvider();
        firebase.auth().signInWithPopup(googleAuthProvider);
    }

    return (
        <div>
            <button onClick={OAuth} className = 'btn btn-primary'>Login with Gmail</button>
        </div>
    )
}