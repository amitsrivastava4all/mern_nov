import React, { useRef, useState } from 'react';
import { ajaxOperations } from '../../utils/ajax';
import { config } from '../../utils/config';
export const Question = ()=>{
    const name =  useRef('');
    const ans1 =  useRef('');
    const ans2 =  useRef('');
    const ans3 =  useRef('');
    const ans4 =  useRef('');
    const rans =  useRef('');
    const score =  useRef('');
    const [message, setMessage] = useState('');

    const answers = (answer,score=0, correctAns='N')=>{
        return {name:answer.current.value,score:score.current.value, rans:correctAns};
    }

    const addQuestion = ()=>{
        const answersArray = [];
        if(rans.current.value == '1'){
            answersArray.push(answers(ans1, score, 'Y'));
        }
        else{
            answersArray.push(answers(ans1, score, 'N'));
        }
        if(rans.current.value == '2'){
            answersArray.push(answers(ans2, score, 'Y'));
        }
        else{
            answersArray.push(answers(ans2, score, 'N'));
        }

        if(rans.current.value == '3'){
            answersArray.push(answers(ans3, score, 'Y'));
        }
        else{
            answersArray.push(answers(ans3, score, 'N'));
        }

        if(rans.current.value == '4'){
            answersArray.push(answers(ans4, score, 'Y'));
        }
        else{
            answersArray.push(answers(ans4, score, 'N'));
        }

        const questionObject = {
            name:name.current.value,
            answers:answersArray
        }
        console.log('Question Object is ', questionObject);
        const promise = ajaxOperations.post(config.URLS.QUESTION_ADD_URL, questionObject);
        promise.then(response=>{
            setMessage(response.data);
            console.log('Data is ',response);
        }).catch(err=>{
            //setMessage(err);
            console.log('Error in Add ',err);
        })
    }

    return (
        <>
            <h1 className = 'alert-info text-center'>Add Question</h1>
            <p>{message}</p>
            <div className='form-group'>
                <label>Name</label>
                <textarea ref={name} className='form-control' cols="20" rows="5" placeholder='Type Question Here'></textarea>
            </div>
            <div className='form-group'>
                <label>Answer1</label>
                <input ref={ans1} type='text' className='form-control'  placeholder='Type First Ans'/>
            </div>
            <div className='form-group'>
                <label>Answer2</label>
                <input ref={ans2} type='text' className='form-control'  placeholder='Type Second Ans'/>
            </div>
            <div className='form-group'>
                <label>Answer3</label>
                <input ref={ans3} type='text' className='form-control'  placeholder='Type Third Ans'/>
            </div>
            <div className='form-group'>
                <label>Answer4</label>
                <input ref={ans4} type='text' className='form-control'  placeholder='Type Fourth Ans'/>
            </div>
            <div className='form-group'>
                <label>Right Ans</label>
                <input ref={rans} type='text' className='form-control'  placeholder='Type Right Ans'/>
            </div>
            <div className='form-group'>
                <label>Right Ans Score</label>
                <input ref={score} type='text' className='form-control'  placeholder='Type Right Score B/W (1 to 4)'/>
            </div>
            <div className='form-group'>
                <button onClick={addQuestion} className='btn btn-primary'>Add</button>
            </div>
        </>
    )
}