export const config = {
    // Server Calls
    URLS :{
        BASEURL:'http://localhost:1234',
        QUESTION_ADD_URL : '/questions/addquestion',
        QUESTION_FETCH_URL:'/questions/getquestions',
        MENU_FETCH_URL:'/menus',

    },
    // Client Side Routing
    ROUTES:{
        HOME:'/',
        ADD_QUESTION:'/addquestion',
        VIEW_QUESTIONS:'/viewquestions'

    },
    SCHEMAS:{
        ROLE:'roles',
        RIGHT:'rights'
    }
}