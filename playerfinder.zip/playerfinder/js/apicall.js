//callPlayer();
function callPlayer(){
    const playerid = document.querySelector('#dt').value;
    const URL =`https://cricapi.com/api/playerStats?pid=${playerid}&apikey=A8zoDoPaQgefmB7KunnSuApSgL73`;
    //const promise = fetch(URL);
    const promise = fetch(URL,{method:'POST',body:{},headers:[{}]});
    promise.then(response=>{
        response.json().then(result=>{
            let player = new Player(result.fullName, result.imageURL,result.battingStyle,result.born,result.playingRole);
            printPlayer(player);
        }).catch(err=>console.log('Invalid JSON ',err))
    }).catch(err=>console.log('Unable to Connect...'));
}
function printPlayer(player){
    let details = document.querySelector('#details');
    details.innerHTML = '';
    var p = document.createElement('p');
    p.innerText = `Name : ${player.name} Born : ${player.born}`;
    details.appendChild(p);
    var img = document.createElement('img');
    img.src = player.photo;
    details.appendChild(img);
}