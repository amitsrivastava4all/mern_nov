class Player{
    constructor(name, photo, battingStyle, born,playingRole){
        this.name = name;
        this.photo = photo;
        this.battingStyle = battingStyle;
        this.born = born;
        this.playingRole = playingRole;
    }
}