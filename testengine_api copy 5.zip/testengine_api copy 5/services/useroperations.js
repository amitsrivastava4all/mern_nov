/**
 * Maintain User CRUD Operations
 * @author Amit Srivastava
 * @copyright Brain Mentors
 * @version 1.0
 * @summary User CRUD File
 */
 const UserModel = require('../db/models/userschema');
 const RoleModel = require('../db/models/roleschema');
const userOperations = {

   async getRoleId(currentRoleName){
       console.log('Current Role Name :::: ',currentRoleName);
       try{
        var roleInfo = await RoleModel.findOne({"name":currentRoleName});
       }
       catch(err){
        return err;
       }
       return roleInfo;
    },

    async oAuth(userObject){
        console.log("######## User Object ##### ",userObject);
        try{
        var user =  await UserModel.findOne({'email':userObject.email })
        .populate({path:'roleid'
        ,populate:{path:'rightid'}
     }).exec();
     console.log('User Role ::: ',user);
     //var rights = await RoleModel.findOne({"_id": user.roleid._id}).populate({path:'rightid', select:'name url'}).exec();
     //user.roleid.rightid = rights;
        //await UserModel.findOne({'email':userObject.email })
        //.populate('roleid').populate('rightid');
        console.log('UserObject is ::::: ', userObject);
        if(!user){
            await UserModel.create(userObject);
        //}
         // check role and right

            user = await UserModel.findOne({'email':userObject.email })
        .populate({path:'roleid'
        ,populate:{path:'rightid'}
    }).exec();
    console.log(':::: User Info :::: ',user);
}
    //var rights = await RoleModel.findOne({"_id": user.roleid._id}).populate({path:'rightid', select:'name url'}).exec();
   // user.roleid.rightid = rights;

        }
        catch(err){
            console.log('Error in OAuth ',err);
            return err;
        }
        return user;
    }
}
module.exports = userOperations;