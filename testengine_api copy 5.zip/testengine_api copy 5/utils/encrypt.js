var bcrypt = require('bcryptjs');
const constants = require('./constants');
var salt = bcrypt.genSaltSync(constants.SALT);
const encryptOperations = {
    generate(plainPassword){
        var hash = bcrypt.hashSync(plainPassword, salt);
        return hash;
    },
    compareHash(plainPassword, dbPassword){
        var isResult = bcrypt.compareSync(plainPassword,dbPassword);
        return isResult;
    }
}
module.exports = encryptOperations;

 
