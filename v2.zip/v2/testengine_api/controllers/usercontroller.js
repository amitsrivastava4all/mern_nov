const userController = {
    login (request, response){
        response.send('login Route');
    },
    register(request, response){
        response.send('Register Route');
    }
}
module.exports = userController;
