const questionController = {
    addQuestion(request, response){

            response.send('Add Question Route');

    },
    getQuestion(request, response){
        response.send('Get Question Route');
    }
}
module.exports = questionController;