const express = require('express');
const route = express.Router();
const questionController = require('../controllers/questioncontroller');
route.post('/addquestion',questionController.addQuestion);
route.get('/getquestion',questionController.getQuestion);
module.exports = route;