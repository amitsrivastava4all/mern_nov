import React, { useState } from 'react'
 const App = (props)=>{
   console.log('Props ',props);
  const [plus, setPlus] = useState(0);
  const plusIt = ()=>{
    setPlus(plus + 1);
  }
  return (<div><h1 className='alert'>I am App</h1>
  <p id='p1'>Value is {plus}</p>
  <p id="x">{props.x}</p>
  <button onClick={plusIt} className='btn'>Click</button>
  </div>);
}
export default App;