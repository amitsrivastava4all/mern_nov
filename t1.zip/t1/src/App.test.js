import {shallow, configure} from 'enzyme';
import App from './App';
import EnzymeAdapter from 'enzyme-adapter-react-16';
import React from 'react';

// Adapter Configure
configure({adapter:new EnzymeAdapter()});

// Test Suite
describe('<App/>',()=>{

  // Test Case
  test("Check <App/> Component is Present or Not",()=>{
    const wrapper = shallow(<App/>); // Rendering the App Component
    expect(wrapper.find(App)).toBeTruthy();
  });

  test("Check <App/> h1 is exist or Not",()=>{
    const wrapper = shallow(<App x="100"/>);
    const h1 = wrapper.find(".alert");
    console.log('H1 is ',h1);
    console.dir(expect(h1).to);
    expect(h1).toHaveLength(1);
  });

  test("Check <App/> h1 is exist or Not",()=>{
    const wrapper = shallow(<App/>);
    const h1 = wrapper.find(".alert");
    console.log('H1 is ',h1);
    console.dir(expect(h1).to);
    expect(h1).toHaveLength(1);
  });

  test("Check Button is Clicked and Value is Incremented",()=>{
    const wrapper = shallow(<App/>);

    const button = wrapper.find(".btn");
    button.simulate('click');
    const pTag = wrapper.find("#p1");
    console.log('PTag ',pTag.text());
    expect(pTag.text().includes('Value is 1')).toBeTruthy();
    //expect(h1).toHaveLength(1);
  });

});


