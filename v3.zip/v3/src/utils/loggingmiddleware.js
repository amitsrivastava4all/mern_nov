import { lazy } from "./async";

export const LoggerMiddleWare = ()=>{

    return next=>{
        return async (action) =>{
            console.log('$$$$$$$$$Middleware Starts ',action );
            var d = await lazy();
            action.payload.d = d;
            const result = next(action);
            console.log('$$$$$$$$$After Next ',result, action);
            return result;
        }
    }
}