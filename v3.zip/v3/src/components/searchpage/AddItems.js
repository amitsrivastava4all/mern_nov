import React, {createRef, useEffect, useRef, useState} from "react";

export const AddItems = (props)=>{

    const [message, setMessage] = useState('');
    const [count, setCount] = useState(0);
    const [errors, setErrors] = useState({'nameError':'', 'ageError':'' });
    const name = useRef();
    const age = useRef();
    const address = useRef();
    const addProduct = ()=>{
        let msg = `Name ${name.current.value} Age ${age.current.value} Address ${address.current.value}`;
        setMessage(msg);

    }

    const errorStyle = {
        color:'red'
    }

    const plusCount = ()=>{
        setCount(count+1);
    }


    useEffect(()=>{
        console.log('################# ComponentDidMount ANd ComponentDidUpdate...');
    });

    useEffect(()=>{
        console.log('################# ComponentDidMount...');
        return ()=>{
            console.log('Component Will UnMount Call');
        }
    },[]);

    useEffect(()=>{
        console.log('************************  (COUNT Updation) ComponentDidUpdate');
    },[count]);


    const validateName=(event)=>{
        let str= event.target.value;
        if(str.length==0){
            setErrors({...errors, 'nameError':'Name Cant Be Blank'});
        }
        else
        if(str.length<3){
            setErrors({...errors, 'nameError':'Name is Too Short'});
        }
        else{
            setErrors({...errors, 'nameError':''});
        }
    }

    const validateAge=(event)=>{
        let str= event.target.value;
        if(str.length==0){
            setErrors({...errors, 'ageError':'Age Cant Be Blank'});
        }
        else
        if(str<10){
            setErrors({...errors, 'ageError':'Age is Less than 10'});
        }
        else{
            setErrors({...errors, 'ageError':''});
        }
    }

    return (
        <>
            <h2>{message} Count is {count}</h2>

            <input onChange = {validateName} ref={name} type='text' placeholder='Type Name'/>
            <span style={errorStyle}>{errors.nameError}</span>
            <br/>
            <input onChange = {validateAge} ref={age} type='text' placeholder='Type Age'/>
            <span style={errorStyle}>{errors.ageError}</span>
            <br/>
            <input ref={address} type='text' placeholder='Type Address'/>
            <br/>
            <button onClick={addProduct}>Add Product</button>
            <button onClick={plusCount}>Count Plus {count}</button>
            </>
    )
}


/*
export class AddItems extends React.PureComponent{
    constructor(props){
        super(props);
        this.state ={message:''};
        this.name = createRef();
        this.age = 0;
        //this.age = createRef();
        this.address = createRef();

    }

    getAge(element){
        console.log('ELement is ======> ',element);
        console.dir(element);
        if(element && this.name.current && this.address.current){
        this.age  = element.value;
        console.log('Age is Set ', this.age);
        let msg = `Name ${this.name.current.value} Age ${this.age} Address ${this.address.current.value}`;
        this.setState({message:msg});
        }
    }

    addProduct(){
        // let name = this.refs.t1.value;
        // let age = this.refs.t2.value;
        // let address = this.refs.t3.value;
        let msg = `Name ${this.name.current.value} Age ${this.age} Address ${this.address.current.value}`;
        this.setState({message:msg});
    }

    render(){
        // {/* <input ref="t1" type='text' placeholder='Type Name'/> */
    //}
    /*
        return (
            <>
            <h2>{this.state.message}</h2>

            <input ref={this.name} type='text' placeholder='Type Name'/>
            <br/>
            <input ref={this.getAge.bind(this)} type='text' placeholder='Type Age'/>
            <br/>
            <input ref={this.address} type='text' placeholder='Type Address'/>
            <br/>
            <button onClick={this.addProduct.bind(this)}>Add Product</button>
            </>
        );
    }
}*/
