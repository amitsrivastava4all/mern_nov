const config = {
    icons:{
        trash:'fas fa-trash',
        edit:'fas fa-edit mr-2',
        hand:'hand'
    }
}