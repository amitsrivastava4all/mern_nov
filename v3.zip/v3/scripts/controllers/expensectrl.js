window.addEventListener('load',init);
function bindEvents(){
    document.querySelector('#add').addEventListener('click',add);
    document.querySelector('#delete').addEventListener('click',deleteMarked);
    document.querySelector('#save').addEventListener('click',save);
    document.querySelector('#load').addEventListener('click',load);
}

function save(){
    if(window.localStorage){
        let jsonString = JSON.stringify(expenseOperations.getExpenses());
        localStorage.expenses = jsonString;
        alert('Data Saved....');
    }
    else{
        alert('Outdated Browser , Plz Update to Save the Data');
    }
}

function load(){
    if(window.localStorage){
        if(window.localStorage.expenses){
            let expenses = JSON.parse(window.localStorage.expenses);
            expenseOperations.expenses = expenses;
            printExpenses();
        }
        else{
            alert('No Data to Load...');
        }
    }
    else{
        alert('Outdated Browser , Plz Update to Load the Data');
    }

}

function deleteMarked(){
    expenseOperations.removeMark();
    printExpenses();


}

function printExpenses(){
    document.querySelector('#expenses').innerHTML = '';
    expenseOperations.getExpenses().forEach(printExpense);
    updateCount();
}

function init(){
    bindEvents();
    updateCount();
}

function updateCount(){
    document.querySelector('#total').innerText = expenseOperations.len();
    document.querySelector('#mark').innerText = expenseOperations.countMark();
    document.querySelector('#unmark').innerText= expenseOperations.len() - expenseOperations.countMark();
}

function add(){
    let id = document.querySelector('#id').value;
    let name = document.querySelector('#name').value;
    let cost = document.querySelector('#cost').value;
    let remarks = document.querySelector('#remarks').value;
    let color = document.querySelector('#color').value;
    let date = document.querySelector('#date').value;
    let photo = document.querySelector('#photo').value;
    let expenseObject = expenseOperations.add(id, name,cost,remarks,photo,color,date);
    printExpense(expenseObject);
    updateCount();
}

function edit(){
    console.log('I am edit');
}

function mark(){
    console.log('I am Mark ',this);
    let id = this.getAttribute('eid');
    expenseOperations.findById(id);
    updateCount();
    //this.parentNode.parentNode.classList.d
    this.parentNode.parentNode.classList.toggle ( 'alert-danger');
}

function createIcon(iconClass, fn,id){
    let iTag = document.createElement('i');
    iTag.className = `${iconClass} ${config.icons.hand}`;
    iTag.addEventListener('click', fn);
    iTag.setAttribute('eid',id);
    return iTag;
}

function printExpense(expenseObject){
    let tbody = document.querySelector('#expenses');
    let tr = tbody.insertRow();
    let index = 0;
    for(let key in expenseObject){
        if(key=='isMarked'){
            continue;
        }
        tr.insertCell(index).innerText = expenseObject[key];
        index++;
        //console.log(expenseObject[key]);
    }
    let td = tr.insertCell(index);
    td.appendChild(createIcon(config.icons.edit, edit, expenseObject.id));
    td.appendChild(createIcon(config.icons.trash, mark,expenseObject.id));
}