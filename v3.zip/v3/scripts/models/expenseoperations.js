const expenseOperations = {
    expenses:[],

    add(id, name, cost, remarks, photo, color, date){
        var expenseObject = new Expense(id,name,cost,remarks,date,color,photo);
        this.expenses.push(expenseObject);
        return expenseObject;
    },
    getExpenses(){
        return this.expenses;
    },
    removeMark(){
        this.expenses = this.expenses.filter(expense=>!expense.isMarked);
    },

    len(){
        return this.expenses.length;
    },
    findById(id){
        let expenseObject = this.expenses.find(expense=>expense.id==id);
        if(expenseObject){
            expenseObject.isMarked= !expenseObject.isMarked;
        }
    },
    countMark(){
        return this.expenses.filter(expense=>expense.isMarked).length;
    }
}

