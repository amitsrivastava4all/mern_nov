/**
 * Maintain Question CRUD Operations
 * @author Amit Srivastava
 * @copyright Brain Mentors
 * @version 1.0
 * @summary Question CRUD File
 */

const QuestionModel = require('../db/models/questionschema');
const questionOperations = {
    add(questionObject){
            const promise = QuestionModel.create(questionObject);
            return promise;
    },
    delete(id){
            /*QuestionModel.remove({"name":name},(err)=>{
                if(err){

                }
                else{

                }
            })*/
            QuestionModel.findByIdAndDelete(id,(err, doc)=>{
                if(err){

                }
                else{

                }
            })
    },
    update(id){
        QuestionModel.findOneAndUpdate({name:'XYZ'},{name:'ABCD'},(err,doc)=>{
            if(err){

            }
            else{

            }
        })
        // QuestionModel.updateMany({id:id},{name:'ABCD'},(err)=>{
        //     if(err){

        //     }
        //     else{

        //     }
        // })
       /* QuestionModel.findByIdAndUpdate(id,{name:'ABCD',age:21},(err, doc)=>{
            if(err){

            }
            else{

            }
        })*/
    },
    findByQuestionId(id){
        const promise = new Promise((resolve, reject)=>{
            QuestionModel.findById(id,(err,doc)=>{
                if(err){
                    reject(err);
                }
                else{
                    resolve(doc);
                }
            })
        })
        return  promise;

    },
    findByQuestionName(questionName){
        const regex = new RegExp(questionName, 'i');
        const promise = new Promise((resolve, reject)=>{
        QuestionModel.findOne({'name':{$regex:regex}},(err,doc)=>{
            if(err){
                reject(err);
            }
            else{
                resolve(doc);
            }
        });
    });
    return promise;
    },
     readAll(){
        //await QuestionModel.find({});
       /* QuestionModel.find({name:'Ram'},{age:1,_id:0}, (err, docs)=>{

        })*/
        const promise = new Promise((resolve, reject)=>{

            //QuestionModel.find({},{},{skip:30, limit:10},(err, docs)=>{

           // })
            QuestionModel.find({}, (err, docs)=>{
                if(err){
                    reject(err);
                }
                else{
                    resolve(docs);
                }
            });
        });
        return promise;

    }
}
module.exports =questionOperations;