const userOperations = require('../services/useroperations');
const userController = {
    login (request, response){
        response.send('login Route');
    },
    register(request, response){
        response.send('Register Route');
    },
    async oauth(request, response){
        console.log('BODY is ', request.body);
        const user= request.body;
        console.log('User request ::: ',user);
        const User = require('../dto/user');
        const roleInfo = await userOperations.getRoleId(user.role);
        console.log('RoleInfo ',roleInfo);
        const userObject = new User(user.email, user.name, user.photo,roleInfo._id);

        try{
        const userInfo = await userOperations.oAuth(userObject);
        if(userInfo){

            const token = require('../utils/token');
            let tokenId = token.createToken(userInfo.email);
            response.json({'userinfo':userInfo, 'tokenid':tokenId});
        }
        else{
            response.json({message:'Auth fail'});
        }


    }
    catch(err){
        response.json({message:'Auth fail'});
    }


    },
    getMenus(request, response){
        response.json({
            "menus":[
                {"name":"Home","link":"/"},
                {"name":"Add Question","link":"/addquestion"},
                {"name":"View Questions","link":"/viewquestions"}
            ]
        });
    }

}
module.exports = userController;
