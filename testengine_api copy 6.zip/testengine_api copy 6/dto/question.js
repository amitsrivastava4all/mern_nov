class Question{
    constructor(name, answers, author){
        this.name = name;
        this.answers = answers;
        this.author = author;
    }
}
module.exports = Question;