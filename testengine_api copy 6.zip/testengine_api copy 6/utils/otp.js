const {nanoid} = require('nanoid');

module.exports = function generateOTP(){
    return nanoid(6);
}


console.log(generateOTP());
console.log(generateOTP());
console.log(generateOTP());

