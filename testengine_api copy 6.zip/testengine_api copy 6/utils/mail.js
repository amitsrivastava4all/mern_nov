

const nodemailer = require('nodemailer');

module.exports = async function sendMail(subject, bodyOfMail){
let transporter = nodemailer.createTransport({
    service:'gmail',
    auth: {
      user: 'manojswag@gmail.com', // gmail user
      pass: '9015551015', // gmail password
    },
  });
  const attachments = {
      filename:'abcd.png',
      content: fs.createReadStream('/Users/amit/Documents/test_engine_project/testengine_api/uploads/rocket.png')

    }
  const mailOptions = {
    from: 'manojswag@gmail.com', // sender address
    to: "amit.shashi.srivastava@gmail.com, manojswag@gmail.com", // list of receivers
    subject: subject, // Subject line
    //text: "Hello world?", // plain text body
    html: bodyOfMail, // html body
    attachments:attachments
  }
  try{
  let info = await transporter.sendMail(mailOptions);
  console.log('###################Mail Send ###########', info);
  }
  catch(err){
    console.log('Error in Mail ', err);
  }
}

//sendMail('Hello User ', 'Hello How are You');