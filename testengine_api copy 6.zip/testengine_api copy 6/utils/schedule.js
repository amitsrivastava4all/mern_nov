

var cron = require('node-cron');

cron.schedule('*/2 * * * * *', () => {
    // Backup , Mail , SMS
  console.log('running a task every 2 Sec');
});