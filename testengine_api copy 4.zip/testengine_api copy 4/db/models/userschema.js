/**
 * Maintain User Schema
 * @author Amit Srivastava
 * @copyright Brain Mentors
 * @version 1.0
 * @summary User Schema File
 */

 const connection = require('../connect');
 const {Schema} = require('mongoose');
const { ROLE } = require('../../../testengine_view/src/utils/config').SCHEMAS;
 const UserSchema = new Schema({
     name:{type:Schema.Types.String, required:true, unique:true, min:3, max:25},
     password:{type:Schema.Types.String, required:true,  min:8, max:25},
     phone:{type:Schema.Types.String, required:true},
     email:{type:Schema.Types.String, required:true},
     logintime:{type:Schema.Types.Date,default:new Date()},
     locked:{type:Schema.Types.String, default:'N'},
     failattempts:{type:Schema.Types.Number, default:0},
     roleid:{type:Schema.Types.ObjectId, ref:ROLE}
    //  role:{type:Schema.Types.String, required:true}



 },{timestamps:true});
 const UserModel = connection.model('users',UserSchema);
 module.exports = UserModel;




