/**
 * Maintain Right Schema
 * @author Amit Srivastava
 * @copyright Brain Mentors
 * @version 1.0
 * @summary Right Schema File
 */

 const connection = require('../connect');
 const {Schema} = require('mongoose');
const { config } = require('../../../testengine_view/src/utils/config');
 const RightSchema = new Schema({
     name:{type:Schema.Types.String, required:true, unique:true, min:3, max:25},
     url:{type:Schema.Types.String, required:true},
     status:{type:Schema.Types.String, default:'Y'},

 },{timestamps:true});
 const RightModel = connection.model(config.SCHEMAS.RIGHT,RightSchema);
 module.exports = RightModel;




