const userController = {
    login (request, response){
        response.send('login Route');
    },
    register(request, response){
        response.send('Register Route');
    },
    getMenus(request, response){
        response.json({
            "menus":[
                {"name":"Home","link":"/"},
                {"name":"Add Question","link":"/addquestion"},
                {"name":"View Questions","link":"/viewquestions"}
            ]
        });
    }

}
module.exports = userController;
