const constants = {
    HTTP_CODES :{
        SUCCESS:200,
        SERVER_ERROR:500,
        FILE_NOT_FOUND:404,
        UNAUTHORIZED:401
    }
}
module.exports = constants;