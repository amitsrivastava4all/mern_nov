const express = require('express');
const route = express.Router();
const userController = require('../controllers/usercontroller');
route.post('/login',userController.login);
route.post('/register',userController.register);
route.get('/menus', userController.getMenus);

module.exports = route;