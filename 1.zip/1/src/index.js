import ReactDOM from 'react-dom';
import React from 'react';
import App from './App';
// ReactDOM.render(React.createElement(App)
// ,document.querySelector('#root'));
ReactDOM.render(<App/>,document.querySelector('#root'));