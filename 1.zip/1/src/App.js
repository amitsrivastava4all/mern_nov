import React from 'react';
import './App.css';
import { Header } from './components/Header';
 const App= ()=>{
    const style = {
        backgroundColor:'blue'
    };
    return (<div className='container'>
            <Header/>
        <h1 className='red'>Hello React JS <span style={style}> Hi</span></h1>
        <h2 className='alert-success'>Brain Mentors</h2></div>
        );
    // return React.createElement("h1",null
    // ,React.createElement("span",null,"Hello Span"));
}
export default App;